﻿Add optional presentation assets here.

Examples:
- logo.png
- intro-figure.pdf

The template does not auto-include personal figures or branding.
