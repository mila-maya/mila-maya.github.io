# Thesis Template Notes

Use this file to keep draft notes, outlines, or planning details for your thesis.
Replace the contents with your own material.
